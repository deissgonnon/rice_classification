This program can be run with jupyter notebook.
Create a rice_img folder or rename the dataset folder to rice_img to run the program.